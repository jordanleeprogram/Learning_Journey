var myname = "Jordan"
var age = "24"


document.write( myname + " is " + age,);
