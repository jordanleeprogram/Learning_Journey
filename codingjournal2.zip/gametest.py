answer = input ("Are you ready? (Yes/No)")

if answer.lower().strip() "yes":

    answer = input ("Good. Firstly, are you turning left, or right?").lower().strip() 

    if answer == "left":

            answer input("You encounter danger. Run or fight?")

             if answer == "attack":
                print ("you died lol ")
            
            else print ("Good choice. You got away.")

     elif answer == "right":


     else: print("You died.")  
else:
    print("Too Bad!")